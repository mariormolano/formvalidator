export class Cliente
{
    nombreCliente;
    dniCliente;
    rutCliente;
}